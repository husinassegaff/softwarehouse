<div class="edd_download_buy_button">
	<?php echo oceanwp_edd_add_to_cart_link(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</div>
